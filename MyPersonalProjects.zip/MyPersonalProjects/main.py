
import json
import os
from datetime import datetime

TASKS_FILE = 'tasks.json'

tasks = []


def load_tasks():
    global tasks
    if os.path.exists(TASKS_FILE):
        with open(TASKS_FILE, 'r') as file:
            tasks = json.load(file)
    else:
        tasks = []


def save_tasks():
    with open(TASKS_FILE, 'w') as file:
        json.dump(tasks, file, indent=4)


def add_task(task, priority='Medium', due_date=None):
    tasks.append({
        "task": task,
        "completed": False,
        "priority": priority,
        "due_date": due_date
    })
    save_tasks()
    print(f'Task "{task}" added.')


def view_tasks():
    if not tasks:
        print("No tasks in the list.")
    else:
        print("Your tasks:")
        sorted_tasks = sorted(tasks, key=lambda x: (x['due_date'] or '', x['priority']))
        for i, task in enumerate(sorted_tasks, start=1):
            status = "[X]" if task["completed"] else "[ ]"
            due_date = task['due_date'] if task['due_date'] else 'No due date'
            print(f"{i}. {status} {task['task']} | Priority: {task['priority']} | Due Date: {due_date}")


def mark_task_completed(task_number):
    """Function to mark a task as completed"""
    if 0 < task_number <= len(tasks):
        tasks[task_number - 1]["completed"] = True
        save_tasks()
        print(f'Task {task_number} marked as completed.')
    else:
        print("Invalid task number.")


def delete_task(task_number):
    if 0 < task_number <= len(tasks):
        removed_task = tasks.pop(task_number - 1)
        save_tasks()
        print(f'Task "{removed_task["task"]}" deleted.')
    else:
        print("Invalid task number.")


def edit_task(task_number, new_description):
    if 0 < task_number <= len(tasks):
        tasks[task_number - 1]["task"] = new_description
        save_tasks()
        print(f'Task {task_number} description updated.')
    else:
        print("Invalid task number.")


def main():
    load_tasks()
    while True:
        print("\nTo-Do List Application")
        print("1. Add a Task")
        print("2. View All Tasks")
        print("3. Mark a Task as Completed")
        print("4. Delete a Task")
        print("5. Edit a Task")
        print("6. Quit")
        choice = input("Choose an option (1/2/3/4/5/6): ")

        if choice == '1':
            task = input("Enter the task: ")
            priority = input("Enter priority (High, Medium, Low): ")
            due_date = input("Enter due date (YYYY-MM-DD) or leave blank: ")
            if due_date:
                try:
                    datetime.strptime(due_date, '%Y-%m-%d')
                except ValueError:
                    print("Invalid date format. Task not added.")
                    continue
            add_task(task, priority, due_date)
        elif choice == '2':
            view_tasks()
        elif choice == '3':
            view_tasks()
            try:
                task_number = int(input("Enter the task number to mark as completed: "))
                mark_task_completed(task_number)
            except ValueError:
                print("Please enter a valid number.")
        elif choice == '4':
            view_tasks()
            try:
                task_number = int(input("Enter the task number to delete: "))
                delete_task(task_number)
            except ValueError:
                print("Please enter a valid number.")
        elif choice == '5':
            view_tasks()
            try:
                task_number = int(input("Enter the task number to edit: "))
                new_description = input("Enter the new task description: ")
                edit_task(task_number, new_description)
            except ValueError:
                print("Please enter a valid number.")
        elif choice == '6':
            print("Thank you for using my To-do-list")
            break
        else:
            print("Invalid choice, please try again.")


if __name__ == "__main__":
    main()
